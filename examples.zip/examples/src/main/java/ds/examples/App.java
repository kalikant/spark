package ds.examples;

import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
	private static List<String> data=new ArrayList<>();
		
    public static void main( String[] args )
    {
    	
data.add("hdfs.base.path=hdfs://nnscbhaastest/sit/edm/hadoop/edmmantas/hdata/sit_aml_sri_open/");
data.add("hdfs.source.path=/user/sitamlapp/output/tmp/");
data.add("hdfs.target.path=/user/sitamlapp/output/tmp/");
data.add("historical.extract=N");
data.add("incremental.extract=Y");
data.add("date.format=yyyy_mm_dd");
data.add("partition.start.date=");
data.add("partition.end.date=");
data.add("partition.date=2017_01_06");
data.add("partition.column=ods");
data.add("# hdfs2hdfs,hive2hdfs");
data.add("data.movement=hdfs2hdfs");

for(String str:data)
{
	String[] val=str.split("=");
	if( val.length ==2)
	{
		System.out.println(val[0]);
		System.out.println(val[1]);
	
	}
      
 }
    }
}
