package spark.examples;

public class Sequence2Text {

}
