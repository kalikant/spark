package spark.examples;

public class AuditData {

	private String projectCode;
	private String subProjectCode;
	private String sourceCode;
	private String countryCode;
	private String sourceDatabase;
	private String destinationDatabase;
	private String sourceTableOrFile;
	private String destinationTableOrFile;
	private String sourcePath;
	private String destinationPath;
	private String columnList;
	private String headerString;
	private String trailerString;
	private String sourceRowCount;
	private String destinationRowCount;
	private String dataFetchQuery;
	
	
	public String getDataFetchQuery() {
		return dataFetchQuery;
	}
	public void setDataFetchQuery(String dataFetchQuery) {
		this.dataFetchQuery = dataFetchQuery;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getSubProjectCode() {
		return subProjectCode;
	}
	public void setSubProjectCode(String subProjectCode) {
		this.subProjectCode = subProjectCode;
	}
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getSourceDatabase() {
		return sourceDatabase;
	}
	public void setSourceDatabase(String sourceDatabase) {
		this.sourceDatabase = sourceDatabase;
	}
	public String getDestinationDatabase() {
		return destinationDatabase;
	}
	public void setDestinationDatabase(String destinationDatabase) {
		this.destinationDatabase = destinationDatabase;
	}
	public String getSourceTableOrFile() {
		return sourceTableOrFile;
	}
	public void setSourceTableOrFile(String sourceTableOrFile) {
		this.sourceTableOrFile = sourceTableOrFile;
	}
	public String getDestinationTableOrFile() {
		return destinationTableOrFile;
	}
	public void setDestinationTableOrFile(String destinationTableOrFile) {
		this.destinationTableOrFile = destinationTableOrFile;
	}
	public String getSourcePath() {
		return sourcePath;
	}
	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}
	public String getDestinationPath() {
		return destinationPath;
	}
	public void setDestinationPath(String destinationPath) {
		this.destinationPath = destinationPath;
	}
	public String getColumnList() {
		return columnList;
	}
	public void setColumnList(String columnList) {
		this.columnList = columnList;
	}
	public String getHeaderString() {
		return headerString;
	}
	public void setHeaderString(String headerString) {
		this.headerString = headerString;
	}
	public String getTrailerString() {
		return trailerString;
	}
	public void setTrailerString(String trailerString) {
		this.trailerString = trailerString;
	}
	public String getSourceRowCount() {
		return sourceRowCount;
	}
	public void setSourceRowCount(String sourceRowCount) {
		this.sourceRowCount = sourceRowCount;
	}
	public String getDestinationRowCount() {
		return destinationRowCount;
	}
	public void setDestinationRowCount(String destinationRowCount) {
		this.destinationRowCount = destinationRowCount;
	}
	
	@Override
	public String toString() {
		return "AuditData [projectCode=" + projectCode + ", subProjectCode=" + subProjectCode + ", sourceCode="
				+ sourceCode + ", countryCode=" + countryCode + ", sourceDatabase=" + sourceDatabase
				+ ", destinationDatabase=" + destinationDatabase + ", sourceTableOrFile=" + sourceTableOrFile
				+ ", destinationTableOrFile=" + destinationTableOrFile + ", sourcePath=" + sourcePath
				+ ", destinationPath=" + destinationPath + ", columnList=" + columnList + ", headerString="
				+ headerString + ", trailerString=" + trailerString + ", sourceRowCount=" + sourceRowCount
				+ ", destinationRowCount=" + destinationRowCount + "]";
	}
	
	
}
