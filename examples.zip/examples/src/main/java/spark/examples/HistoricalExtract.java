package spark.examples;

public class HistoricalExtract {

}
