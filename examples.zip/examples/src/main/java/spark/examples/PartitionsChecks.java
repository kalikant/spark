package spark.examples;

public class PartitionsChecks {

}
