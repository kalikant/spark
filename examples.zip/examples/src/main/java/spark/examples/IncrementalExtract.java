package spark.examples;

public class IncrementalExtract {

}
