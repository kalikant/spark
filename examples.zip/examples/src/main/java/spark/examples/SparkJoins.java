package spark.examples;

import java.io.FileNotFoundException;
import java.util.Optional;

import scala.Tuple2;

public class SparkJoins {

	@SuppressWarnings("serial")
    public static void main(String[] args) throws FileNotFoundException {
       
    }
}
